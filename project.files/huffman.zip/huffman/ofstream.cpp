#include <bits/stdc++.h>
#include <fstream>
using namespace std;

int main()
{
	FILE* file = fopen("2.txt", "rb");
	fseek(file,0,SEEK_END);
	int	len=ftell(file);
	fclose(file);
	ifstream input( "2.txt", ios::in | ios::binary );
	char ch[100001];
       	input.read( ( char * ) & ch , len );
	for(int i=0;i<len;i++)printf("%c",ch[i]);
	input.close();
	puts("");
	return 0;
}
